# dev/polish review build

30 September 2026. User requested a local review before deciding whether to merge and publish. This branch changes the presentation and proposed collaboration model; it does not change the lifecycle engine or publish either hosted site.

## Review the build

Open `docs/simulator/index.html`, or the self-contained `deliverables/Silicon-Flow-Studio.html`. The header identifies the development preview. Compact diagram is the default; **Expand diagram** reveals placement notes and supporting component descriptions. The full diagram remains scrollable on smaller displays.

Select any numbered block to inspect its personas, specialist function, inputs, outputs, native authority and five proposed exchanges. **Walk exchange** advances only the explanatory highlight. **Run next step** advances the actual synthetic lifecycle. The displayed simulation state distinguishes pending work, retained evidence and blocked/review states. Inspecting a future block does not produce evidence or skip a gate.

**Agent functions** shows seven shared logical responsibilities and twelve proposed specialist assignments. A logical function is not automatically a separate agent model, process, host or container. The decomposition is a proposal requiring domain review.

## Source and requirement mapping

| Change | Requirements | Source basis |
| --- | --- | --- |
| Five deployment layers; numbered lifecycle/evidence arrows; field feedback to coordination | FR-001/002/004/007/015 | D01 end-to-end boundaries; D02 placement; D03 application decomposition; supplied architecture world view |
| Coordinator, retrieval, specialist advisor, deterministic admission, human reviewer, native adapter and evidence services | FR-007/009/010/011 | D03 **Applications, containers and software delivery**; D04 **Separate thinking from permission and execution** and **Bind approval to exactly what will happen** |
| Accountable personas and stage-specific exchanges | FR-010/012/013/015/016/020/026 | D04–D10 domain ownership; feature 001 spec; feature 004 engine stage owners |
| Protected sensing, root of trust, baseline and separate operating context | FR-020/025/026 | Trusted-Silicon-Health baseline and field-report workflows; D10 |
| Walking an explanation cannot approve or execute anything | FR-010/011/017 | D04 authority boundary; unchanged deterministic lifecycle engine |

The handoff text is an authored proposal derived from those documents, not a transcript of live agents. A highlighted exchange is an illustration, not an extra engine event or proof of an API call. Tool jobs, signatures, measurements and approvals remain fictional. No additional standard-conformance claims are introduced.

## Review boundary

The private repository can hold `dev/polish` for review. No merge to main, release replacement, GitHub Pages update or Sites deployment is part of this request. The public 1.0 simulator remains the delivery baseline until the user approves a later merge/publication.

## Publication approval

On 30 September 2026, after viewing the preview, the user explicitly authorized the pull request, merge and public package publication. The five-layer diagram and personas are accepted for the educational browser release. This approval does not establish domain or production qualification. Release 1.1.0 replaces the public GitHub Pages simulator and download bundle.
