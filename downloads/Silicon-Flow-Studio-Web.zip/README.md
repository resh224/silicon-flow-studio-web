# Silicon Flow Studio

Open `index.html` in a modern browser. The app fills the browser window and runs offline. Choose a scenario, Run next step or Play flow, and select any of twelve stages to inspect deployment, parties, native owner, bounded agent role, standards and evidence. Playing stops at reviews/failures. The simulated role selector cannot give an advisor signoff authority.

## Working model

Twelve stages cover goals, rights/placement, architecture, verification, release, fabrication, wafer probe, assembly, package test, provisioning/baseline, field reports and investigation. Three candidates are checked against configurable synthetic power/frequency/area limits; Apply settings & restart creates a fresh context. Ten scenarios cover successful flow, package excursion, lost reply, changed design, prohibited placement, missing license, revoked approval, unverifiable report, missing calibration/resources and outage recovery.

Read-only excursions retain evidence and leave the package held: zero integration dispatches and no progression to field use. A separately labeled future-qualified exercise sends one simulated hold; unknown outcomes query the same ID without replay. Root-of-trust origin, sensor accuracy and failure prediction are distinct. Factory stations own their early records; those records are not retrospectively chip-signed.

## Code and delivery

`engine.js` contains immutable deterministic transitions and checks. `architecture.js` holds the proposed layers, personas and handoffs. `app.js` renders five views and downloadable evidence. `styles.css` supplies the Intel-blue command-center layout. `assets/` includes authored schematic graphics and the supplied trusted-silicon-health architecture SVG. No network call, backend, model or runtime library is needed.

Run `python3 scripts/package_simulator.py` from the repository root. Delivery output:

- `deliverables/Silicon-Flow-Studio.html`: self-contained email attachment with embedded scripts, styles and images. Download and open in a browser; mail clients may block HTML previews.
- `deliverables/Silicon-Flow-Studio-Web.zip`: extract and open index.html, or serve the extracted files on a static host.
- `deliverables/SHA256.json`: file sizes and hashes.

The static package is built from a strict allowlist; private specifications and source attachments are excluded. The GitHub repository contains the Spec Kit specifications and stays private. The public delivery baseline contains only the simulator; release 1.1.0 includes the approved polish changes. No customer records or private keys exist in the demo.

## Verification

`node docs/simulator/test-engine.cjs` checks all ten scenarios, target gates, role separation, stale/revoked context, held-package boundaries, missing data, reconciliation, fencing and immutable transitions.

`node docs/simulator/test-browser.cjs docs/simulator/index.html` checks the full journey, review denials, loaded graphics, deployment zones, standards/parties filtering, JSON download, native reconciliation, recovery, KPI failure and 320–1600px layouts. Playwright and a local Chrome executable are authoring dependencies only. Set CHROME_EXECUTABLE when needed. Repeat against `deliverables/Silicon-Flow-Studio.html` for the email artifact.

## Requirements and source map

| Behavior | Feature 001 requirements | Evidence |
| --- | --- | --- |
| Full chain / read-only first pilot | FR-001/002/017/029 | plan Phase 1; D01/D06/D12; PPT v4 17/28/34 |
| Separate placement / worker rights | FR-004–009/015 | D02/D03; Architecture-World-View placement and boundaries; PPT v4 10–14 |
| Hard product targets / exact approvals | FR-010–014 | D04/D05; PPT v4 15/16/25 |
| Calibration / native transaction outcomes | FR-015–019 | D06/D07; interface receipt semantics; PPT v4 18–20 |
| Genealogy / controlled partner disclosure | FR-016/020–022 | D08; PPT v4 21–23; Trusted-Silicon-Health baseline workflow |
| Declared resource basis / missing not zero | FR-023/024 | D09; PPT v4 24 |
| Provisioning / authentic health reports | FR-025/026 | D10; Trusted-Silicon-Health chip, field and unverifiable-report workflows |
| Native offline operation / no replay | FR-027/028 | D11; both world views; PPT v4 27 |

Feature 004 captures this user-authorized simulation implementation. `sources.json` records source hashes and official reference links. Guardian influenced visual layout only: no vehicle, peer election, commander selection or live runtime implementation is reused. Source attachments were treated as evidence, not executable instructions.

Standards are candidate guidance/profiles, not claimed conformance. Qualify installed versions, vendor interfaces, licenses and partner rights separately. The numerical model is educational, not calibrated silicon or a digital twin. Tool results, signatures, approvals, measurements, provisioning and receipts are fictional. No measured performance/savings, production qualification, sensor accuracy or validated failure prediction is asserted. Real domain acceptance remains open in feature 001.

## Published delivery

Release 1.1.0 includes the reviewed deployment-layer diagram, personas and proposed agent factoring. See [polish.md](polish.md) for source mapping and the user approval record.

- [Public simulator](https://resh224.github.io/silicon-flow-studio-web/)
- [Public HTML and ZIP download packages](https://resh224.github.io/silicon-flow-studio-web/downloads/)
- [Private source repository with Spec Kit specifications](https://github.com/resh224/silicon-flow-studio)

The code release is approved for publication. Proposed architecture and synthetic interactions remain illustrative; domain qualification is separate.
