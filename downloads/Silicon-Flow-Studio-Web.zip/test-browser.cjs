const {chromium}=require('playwright');
const assert=require('node:assert/strict');
const path=require('node:path');
(async()=>{
 const browser=await chromium.launch({headless:true,executablePath:process.env.CHROME_EXECUTABLE||'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'});
 const page=await browser.newPage({viewport:{width:1600,height:1050}}),errors=[];
 page.on('pageerror',e=>errors.push(e.message));
 await page.goto('file://'+path.resolve(process.argv[2]||path.join(__dirname,'index.html')));
 const $=id=>page.locator('#'+id),next=async n=>{for(let i=0;i<n;i++)await $('advance').click()};
 assert.equal(await page.locator('.stage-node').count(),12);
 assert.equal(await page.locator('.architecture-layer').count(),5);
 assert.deepEqual(await page.locator('.architecture-layer').evaluateAll(es=>es.map(e=>[e.dataset.layer,[...e.querySelectorAll('[data-stage]')].map(n=>Number(n.dataset.stage))])),[
  ['coordination',[0,11]],['design',[1,2,3,4]],['partner',[5,7]],['factory',[6,8,9]],['field',[10]]
 ]);
 await page.waitForFunction(()=>document.querySelectorAll('#paths path').length===11);
 assert.deepEqual(await page.locator('#paths path').evaluateAll(es=>es.map(e=>[Number(e.dataset.from),Number(e.dataset.to)])),Array.from({length:11},(_,i)=>[i,i+1]));
 // Explanation controls and future-stage inspection cannot advance the exercise.
 const initialCount=await $('step-count').innerText();
 await page.locator('[data-stage="8"]').click();
 assert.match(await $('inspector').innerText(),/Quality owner/);
 assert.match(await $('inspector').innerText(),/Not run/);
 assert.equal(await page.locator('.persona-row').count(),3);
 assert.equal(await page.locator('.exchange li').count(),5);
 const firstExchange=await page.locator('.exchange-current').innerText();
 await $('walk-exchange').click();assert.notEqual(await page.locator('.exchange-current').innerText(),firstExchange);
 assert.equal(await $('step-count').innerText(),initialCount);
 await $('diagram-density').click();assert.equal(await $('lifecycle-map').getAttribute('class'),'');
 await $('diagram-density').click();assert.equal(await $('lifecycle-map').getAttribute('class'),'compact');
 await page.getByRole('button',{name:'Agent functions',exact:true}).click();
 assert.equal(await page.locator('.function-card').count(),7);
 assert.equal(await page.locator('.specialist-card').count(),12);
 assert.match(await $('agent-functions').innerText(),/Deterministic admission/);
 await page.locator('[data-specialist-stage="4"]').click();assert.match(await $('inspector').innerText(),/Design signer/);
 assert.equal(await $('step-count').innerText(),initialCount);
 await page.locator('[data-stage="0"]').click();
 assert.equal(await page.locator('img').evaluateAll(es=>es.every(e=>e.complete&&e.naturalWidth>0)),true);
 await next(5);assert(await $('advance').isDisabled());assert(await $('play').isDisabled());
 await $('review-role').selectOption('System C2 advisor');await page.getByRole('button',{name:'Approve exact design release',exact:true}).click();assert.match(await $('flow-notice').innerText(),/Decision denied/);
 await $('review-role').selectOption('Design signer');await page.getByRole('button',{name:'Approve exact design release',exact:true}).click();await next(7);
 assert.match(await $('flow-notice').innerText(),/Reliability engineer/);await page.getByRole('button',{name:'Approve confirmation-test plan',exact:true}).click();assert.equal(await $('step-count').innerText(),'12 / 12 stages completed');
 await page.getByRole('button',{name:'Evidence & decisions',exact:true}).click();assert.match(await $('evidence-summary').innerText(),/Integration dispatches 0/);
 const downloadPromise=page.waitForEvent('download');await $('export').click();const download=await downloadPromise;assert.equal(download.suggestedFilename(),'silicon-flow-demo-evidence.json');
 await page.getByRole('button',{name:'Deployment world',exact:true}).click();assert.equal(await page.locator('.deployment-zone').count(),6);assert(await page.getByText('Metrology / test',{exact:true}).isVisible());
 await page.getByRole('button',{name:'Standards & parties',exact:true}).click();await $('standards-stage').selectOption('6');assert.match(await $('standards-list').innerText(),/SEMI E142/);assert.match(await $('parties-list').innerText(),/wafer-test operator/);
 await page.getByRole('button',{name:'Lifecycle flow',exact:true}).click();await $('scenario').selectOption('lost');await next(5);await page.getByRole('button',{name:'Approve exact design release',exact:true}).click();await next(4);await page.getByRole('button',{name:'Approve simulated native hold',exact:true}).click();assert.match(await $('flow-notice').innerText(),/Outcome unknown/);await page.getByRole('button',{name:'Query the same native transaction',exact:true}).click();await page.getByRole('button',{name:'Confirmed requested hold',exact:true}).click();
 await $('show-evidence').click();assert.match(await $('evidence-summary').innerText(),/Integration dispatches 1/);
 await page.getByRole('button',{name:'Lifecycle flow',exact:true}).click();await $('scenario').selectOption('offline');await next(5);await page.getByRole('button',{name:'Approve exact design release',exact:true}).click();await next(4);await page.getByRole('button',{name:'Restore, fence & reconcile',exact:true}).click();assert.match(await $('flow-notice').innerText(),/No buffered commands/);await next(1);
 await $('scenario').selectOption('normal');await $('candidate').selectOption('cache');await $('apply').click();await next(4);assert.match(await $('flow-notice').innerText(),/fails an approved product target/);
 await $('candidate').selectOption('balanced');await $('apply').click();await next(3);
 for(const width of [1600,1280,768,375,320]){
  await page.setViewportSize({width,height:1050});
  for(const view of ['Lifecycle flow','Agent functions','Deployment world','Standards & parties','Evidence & decisions']){
   await page.getByRole('button',{name:view,exact:true}).click();
   assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1),false,'overflow '+view+' '+width);
  }
 }
 await page.setViewportSize({width:1600,height:1050});await page.getByRole('button',{name:'Lifecycle flow',exact:true}).click();
 const folder=process.env.SCREENSHOT_DIR||'/private/tmp';await page.screenshot({path:path.join(folder,'silicon-studio-desktop.png'),fullPage:true});
 await page.setViewportSize({width:375,height:1050});await page.screenshot({path:path.join(folder,'silicon-studio-mobile.png'),fullPage:true});
 assert.deepEqual(errors,[]);await browser.close();console.log('PASS: five deployment layers; all 11 lifecycle handoffs; persona and exchange exploration without advancing state; seven factored functions and twelve specialists; density controls; full native lifecycle; role denial / approvals; image loads; six deployment zones; standards filtering; evidence export; single-dispatch reconciliation; outage recovery; KPI failure; five views at 320–1600px.');
})().catch(e=>{console.error(e);process.exit(1)});
