const assert=require('node:assert/strict');
const E=require('./engine.js');
function until(s,id){for(let guard=0;E.STAGES[s.step].id!==id&&s.status==='ready'&&guard<20;guard++)s=E.advance(s);return s;}
function released(config){let s=until(E.create(config),'release');s=E.advance(s);return E.act(s,'approve','Design signer');}
let s=E.create();s=until(s,'release');s=E.advance(s);assert.equal(s.status,'review');
let denied=E.act(s,'approve','System C2 advisor');assert.equal(denied.status,'review');assert.equal(denied.approval.approved,false);assert.equal(denied.dispatches,0);
s=E.act(s,'approve','Design signer');s=until(s,'investigate');assert.equal(s.fieldTrusted,true);assert.equal(s.quality,'native-accepted-in-model');s=E.advance(s);s=E.act(s,'approve','Reliability engineer');assert.equal(s.status,'complete');assert.equal(s.done.length,12);assert.equal(s.dispatches,0);
for(const candidate of ['cache','lowpower']){let t=until(E.create({candidate}),'verify');t=E.advance(t);assert.equal(t.status,'blocked');assert(!t.done.includes('release'));}
for(const scenario of ['stale','revoked']){let t=released({scenario});assert.equal(t.status,'blocked');assert.equal(t.dispatches,0);assert(!t.artifacts.some(a=>a.kind==='RELEASE'));}
let t=E.advance(E.advance(E.create({scenario:'rights'})));assert.equal(t.status,'blocked');
t=E.advance(E.advance(E.create({scenario:'rights',placement:'private'})));assert.equal(t.status,'ready');
t=until(E.create({scenario:'license'}),'verify');t=E.advance(t);assert.equal(t.status,'blocked');assert(!t.artifacts.some(a=>a.kind==='EDA-RUN'));
t=until(released({scenario:'excursion'}),'test');t=E.advance(t);assert.equal(t.quality,'held');t=E.act(t,'review','Quality owner');assert.equal(t.status,'complete');assert.equal(t.dispatches,0);assert(!t.done.includes('provision'));
for(const outcome of ['confirmed','pending','partial']){let a=until(released({scenario:'lost'}),'test');a=E.advance(a);a=E.act(a,'hold','Quality owner');assert.equal(a.status,'unknown');assert.equal(a.dispatches,1);const noRetry=E.act(a,'hold','Quality owner');assert.equal(noRetry.dispatches,1);a=E.act(a,'query','Quality owner');a=E.act(a,outcome,'Quality owner');assert.equal(a.dispatches,1);assert.equal(a.status,outcome==='confirmed'?'complete':'blocked');assert(!a.done.includes('provision'));}
t=until(released({scenario:'missing'}),'test');t=E.advance(t);assert.equal(t.status,'blocked');assert.equal(t.artifacts.at(-1).details.power,null);
t=until(released({scenario:'report'}),'field');t=E.advance(t);assert.equal(t.status,'blocked');assert.equal(t.fieldTrusted,false);
t=until(released({scenario:'offline'}),'test');t=E.advance(t);assert.equal(t.status,'offline');assert.equal(t.buffer.length,1);t=E.act(t,'recover');assert.equal(t.epoch,4);assert.equal(t.dispatches,0);assert.equal(t.config.scenario,'offline');t=E.advance(t);assert.equal(t.status,'ready');
const original=E.create(),snapshot=JSON.stringify(original);E.advance(original);assert.equal(JSON.stringify(original),snapshot);
console.log('PASS: 10 scenarios; hard product limits; reviewer role separation; stale/revoked context; missing evidence; held-package boundary; single-dispatch reconciliation; offline fencing and buffered observations; immutable transitions.');
